Metroid Prime 4: Beyond (v1.1.0) - 1080p + 120 FPS, scan-safe
================================================================

Two mods for emulators (Eden, Eden Kledd, Citron, Yuzu forks):

  [1920x1080 v1.1.0] Kledd scan-safe
      Fl4sh's 1080p resolution patch, with the scan visor fixed:
      the scan buffer is pinned to the game's native 1600x900, so the
      "ZL Fix scan" cheat is NOT needed and must NOT be used.
      Dynamic resolution is turned off.

  [120FPS Dynamic v1.1.0] v1.0
      Fl4sh's 120 FPS dynamic mod, unchanged.

INSTALL
  1. Right-click Metroid Prime 4 in Eden -> Open Mod Data Location.
  2. Copy both folders from this zip into that folder.
  3. Right-click the game -> Properties -> Add-Ons: make sure both are ticked,
     and that NO other resolution mod or "ZL Fix scan" cheat is ticked.

  If the game takes very long to boot with 120 FPS: boot with the speed limit
  on, then unlock it in-game (Ctrl+U in Eden).

NOTES
  - Game version 1.1.0 only.
  - Only one resolution mod at a time.
  - For the scan visor to work properly on Eden, use a build with the scan fix
    (Eden Kledd, https://github.com/Melos555/eden-kledd).

CREDITS
  Resolution and 120 FPS mods: Fl4sh (https://github.com/Fl4sh9174,
  https://ko-fi.com/Fl4sh9174). All credit for the original patches is his.
  Scan-safe change: Melos (testing) and Claude / Anthropic AI ("Kledd").
